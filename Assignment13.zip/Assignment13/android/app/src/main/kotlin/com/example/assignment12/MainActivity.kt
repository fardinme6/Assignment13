package com.example.assignment12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
